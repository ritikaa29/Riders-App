import { useEffect } from "react";
import { useLocation } from "wouter";
import { Zap, AlertTriangle, Clock, ChevronRight, Battery, MapPin, Wifi } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useAppStore } from "../store/app";
import { apiClient } from "../lib/api";
import { getIssueLabel, getStatusLabel, getStatusClass, formatDateTime } from "../lib/utils";
import triEvLogo from "../assets/triev-logo.png";

export default function HomePage() {
  const [, navigate] = useLocation();
  const user = useAppStore((s) => s.user);
  const setActiveTicket = useAppStore((s) => s.setActiveTicket);

  const { data: tickets, refetch } = useQuery({
    queryKey: ["tickets", user?.id],
    queryFn: () => apiClient.getTickets(user!.id),
    enabled: !!user,
    refetchInterval: 5000,
  });

  const activeTickets = tickets?.filter(
    (t) => !["COMPLETED", "CANCELLED"].includes(t.status)
  ) ?? [];

  const recentTickets = tickets
    ?.filter((t) => ["COMPLETED", "CANCELLED"].includes(t.status))
    ?.slice(0, 2) ?? [];

  const handleTrack = (ticket: (typeof tickets)[0]) => {
    setActiveTicket(ticket);
    navigate(`/tracking/${ticket.id}`);
  };

  const battery = user?.batteryLevel ?? 85;
  const batteryColor = battery > 50 ? "#4ade80" : battery > 20 ? "var(--warn)" : "var(--err)";

  return (
    <div className="px-4 pt-5 pb-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-6 animate-slide-up">
        <div>
          <p className="text-[var(--text2)] text-sm font-medium">Good day,</p>
          <h1 className="font-display font-bold text-2xl text-white mt-0.5">{user?.name} 👋</h1>
        </div>
        <img src={triEvLogo} alt="TriEV" className="h-9 w-auto object-contain" />
      </div>

      {/* EV Status Card */}
      <div
        className="rounded-3xl p-5 mb-5 animate-slide-up-delay-1 relative overflow-hidden"
        style={{
          background: "linear-gradient(135deg, #1a0e05 0%, #261508 100%)",
          border: "1px solid var(--border2)",
        }}
      >
        {/* Glow blob */}
        <div
          className="absolute right-0 top-0 w-32 h-32 rounded-full pointer-events-none opacity-30"
          style={{ background: "radial-gradient(circle, var(--accent) 0%, transparent 70%)", transform: "translate(30%, -30%)" }}
        />

        <div className="flex items-start justify-between mb-4">
          <div>
            <p className="text-[var(--text2)] text-xs font-semibold tracking-wider uppercase mb-1">Your EV</p>
            <h3 className="font-display font-bold text-white text-lg">{user?.evModel ?? "TriEV 300"}</h3>
          </div>
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full" style={{ background: "rgba(74,222,128,0.1)", border: "1px solid rgba(74,222,128,0.2)" }}>
            <Wifi size={12} color="#4ade80" />
            <span className="text-xs font-bold text-green-400">Live</span>
          </div>
        </div>

        {/* Battery bar */}
        <div className="mb-3">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <Battery size={16} color={batteryColor} />
              <span className="text-sm font-bold" style={{ color: batteryColor }}>{battery}%</span>
            </div>
            <span className="text-[var(--text3)] text-xs">Battery Level</span>
          </div>
          <div className="h-2.5 rounded-full overflow-hidden" style={{ background: "var(--bg3)" }}>
            <div
              className="h-full rounded-full transition-all duration-1000"
              style={{
                width: `${battery}%`,
                background: `linear-gradient(90deg, ${batteryColor}, ${batteryColor}cc)`,
                boxShadow: `0 0 8px ${batteryColor}80`,
              }}
            />
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <MapPin size={13} style={{ color: "var(--text3)" }} />
          <span className="text-[var(--text3)] text-xs">GPS Active · Last seen: Just now</span>
        </div>
      </div>

      {/* Active Tickets Alert */}
      {activeTickets.length > 0 && (
        <div className="mb-5 animate-slide-up-delay-2">
          <p className="text-[var(--text2)] text-xs font-bold uppercase tracking-wider mb-3">Active Rescue</p>
          {activeTickets.map((ticket) => (
            <button
              key={ticket.id}
              onClick={() => handleTrack(ticket)}
              className="w-full text-left rounded-2xl p-4 flex items-center gap-3 transition-all active:scale-98"
              style={{
                background: "linear-gradient(135deg, rgba(255,107,0,0.12) 0%, rgba(255,107,0,0.06) 100%)",
                border: "1.5px solid rgba(255,107,0,0.35)",
              }}
            >
              <div
                className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ background: "rgba(255,107,0,0.15)" }}
              >
                <Zap size={22} style={{ color: "var(--accent)" }} fill="currentColor" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="font-bold text-sm text-white truncate">{getIssueLabel(ticket.issueType)}</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${getStatusClass(ticket.status)}`}>
                    {getStatusLabel(ticket.status)}
                  </span>
                </div>
                <p className="text-[var(--text2)] text-xs truncate">{ticket.locationText}</p>
                {ticket.eta && <p className="text-[var(--accent)] text-xs font-bold mt-0.5">ETA: {ticket.eta}</p>}
              </div>
              <ChevronRight size={18} style={{ color: "var(--text3)" }} />
            </button>
          ))}
        </div>
      )}

      {/* SOS / Raise Ticket CTA */}
      <button
        onClick={() => navigate("/raise-ticket")}
        className="w-full rounded-3xl p-5 mb-5 animate-slide-up-delay-2 flex items-center gap-4 transition-all active:scale-98"
        style={{
          background: "linear-gradient(135deg, var(--accent) 0%, #FF9500 100%)",
          boxShadow: "0 8px 32px rgba(255,107,0,0.4), 0 2px 8px rgba(0,0,0,0.3)",
        }}
      >
        <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center flex-shrink-0">
          <AlertTriangle size={28} color="white" strokeWidth={2.5} />
        </div>
        <div className="flex-1 text-left">
          <h3 className="font-display font-bold text-white text-xl leading-tight">Need Help?</h3>
          <p className="text-white/80 text-sm font-medium mt-0.5">Raise an SOS ticket instantly</p>
        </div>
        <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
          <ChevronRight size={22} color="white" strokeWidth={2.5} />
        </div>
      </button>

      {/* Recent History */}
      {recentTickets.length > 0 && (
        <div className="animate-slide-up-delay-3">
          <div className="flex items-center justify-between mb-3">
            <p className="text-[var(--text2)] text-xs font-bold uppercase tracking-wider">Recent</p>
            <button
              onClick={() => navigate("/history")}
              className="text-[var(--accent)] text-xs font-bold"
            >
              See All
            </button>
          </div>
          <div className="space-y-2">
            {recentTickets.map((ticket) => (
              <div
                key={ticket.id}
                className="flex items-center gap-3 p-3.5 rounded-2xl"
                style={{ background: "var(--card)", border: "1px solid var(--border)" }}
              >
                <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: "var(--bg3)" }}>
                  <Clock size={16} style={{ color: "var(--text3)" }} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm text-white truncate">{getIssueLabel(ticket.issueType)}</p>
                  <p className="text-[var(--text3)] text-xs mt-0.5">{formatDateTime(ticket.createdAt)}</p>
                </div>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${getStatusClass(ticket.status)}`}>
                  {getStatusLabel(ticket.status)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
