import { useState } from "react";
import { ArrowRight, Zap, Phone } from "lucide-react";
import { useAppStore } from "../store/app";
import { apiClient } from "../lib/api";
import triEvLogo from "../assets/triev-logo.png";

export default function LoginPage() {
  const setUser = useAppStore((s) => s.setUser);
  const [step, setStep] = useState<"phone" | "name">("phone");
  const [phone, setPhone] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handlePhoneNext = () => {
    const digits = phone.replace(/\D/g, "");
    if (digits.length < 10) {
      setError("Enter a valid 10-digit number");
      return;
    }
    setError("");
    setStep("name");
  };

  const handleLogin = async () => {
    setLoading(true);
    setError("");
    try {
      const formatted = `+91${phone.replace(/\D/g, "").slice(-10)}`;
      const user = await apiClient.login(formatted, name || undefined);
      setUser(user);
    } catch (e: any) {
      setError(e.message || "Login failed. Try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="min-h-full flex flex-col relative overflow-hidden"
      style={{ background: "linear-gradient(160deg, #0a0804 0%, #1a0f06 50%, #0d0808 100%)" }}
    >
      {/* Background glow */}
      <div
        className="absolute top-32 left-1/2 -translate-x-1/2 w-96 h-96 rounded-full pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(255,107,0,0.12) 0%, transparent 70%)" }}
      />

      {/* Top section */}
      <div className="flex-1 flex flex-col items-center justify-center px-8 pt-16 pb-8">
        {/* Logo */}
        <div className="animate-slide-up mb-2">
          <img src={triEvLogo} alt="TriEV" className="h-24 w-auto object-contain" />
        </div>

        {/* Tagline */}
        <div className="animate-slide-up-delay-1 text-center mb-12">
          <p className="text-[var(--text2)] text-sm font-medium tracking-widest uppercase">
            Roadside Rescue · Anytime
          </p>
        </div>

        {/* Card */}
        <div
          className="w-full max-w-sm animate-slide-up-delay-2 rounded-3xl p-6"
          style={{ background: "var(--card)", border: "1px solid var(--border2)" }}
        >
          {step === "phone" ? (
            <>
              <div className="flex items-center gap-3 mb-6">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{ background: "var(--accent-dim)", border: "1px solid var(--border2)" }}
                >
                  <Phone size={18} style={{ color: "var(--accent)" }} />
                </div>
                <div>
                  <h2 className="font-display font-bold text-xl text-white">Welcome Back</h2>
                  <p className="text-[var(--text2)] text-xs mt-0.5">Enter your mobile number</p>
                </div>
              </div>

              <div className="flex gap-2 mb-4">
                <div
                  className="flex items-center px-3 rounded-xl font-bold text-sm"
                  style={{
                    background: "var(--bg3)",
                    border: "1.5px solid var(--border2)",
                    color: "var(--text2)",
                  }}
                >
                  🇮🇳 +91
                </div>
                <input
                  type="tel"
                  className="input-field flex-1"
                  placeholder="98765 43210"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handlePhoneNext()}
                  maxLength={12}
                  autoFocus
                />
              </div>

              {error && (
                <p className="text-[var(--err)] text-xs mb-3 font-medium">{error}</p>
              )}

              <button className="btn-primary" onClick={handlePhoneNext}>
                Continue <ArrowRight size={18} />
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => setStep("phone")}
                className="text-[var(--text2)] text-sm font-medium mb-5 flex items-center gap-1 hover:text-white transition-colors"
              >
                ← Back
              </button>

              <div className="mb-6">
                <h2 className="font-display font-bold text-xl text-white mb-1">Your Name</h2>
                <p className="text-[var(--text2)] text-xs">We'll use this to personalize your experience</p>
              </div>

              <input
                type="text"
                className="input-field mb-4"
                placeholder="e.g. Arjun Sharma"
                value={name}
                onChange={(e) => setName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                autoFocus
              />

              {error && (
                <p className="text-[var(--err)] text-xs mb-3 font-medium">{error}</p>
              )}

              <button className="btn-primary" onClick={handleLogin} disabled={loading}>
                {loading ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                    Signing in…
                  </span>
                ) : (
                  <>
                    <Zap size={18} fill="white" />
                    Join the EV Tribe
                  </>
                )}
              </button>
            </>
          )}
        </div>

        {/* Footer */}
        <p className="text-[var(--text3)] text-xs text-center mt-8 animate-slide-up-delay-3 px-6">
          By continuing, you agree to our Terms & Privacy Policy
        </p>
      </div>
    </div>
  );
}
