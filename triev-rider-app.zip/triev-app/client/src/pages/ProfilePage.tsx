import { useState } from "react";
import { User, Phone, Zap, LogOut, Edit3, Check, X, Battery, ChevronRight } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useAppStore } from "../store/app";
import { apiClient } from "../lib/api";
import triEvLogo from "../assets/triev-logo.png";

export default function ProfilePage() {
  const user = useAppStore((s) => s.user);
  const setUser = useAppStore((s) => s.setUser);
  const logout = useAppStore((s) => s.logout);
  const qc = useQueryClient();

  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(user?.name ?? "");
  const [evModel, setEvModel] = useState(user?.evModel ?? "");

  const mutation = useMutation({
    mutationFn: () => apiClient.updateUser(user!.id, { name, evModel }),
    onSuccess: (updated) => {
      setUser(updated);
      setEditing(false);
    },
  });

  if (!user) return null;

  const battery = user.batteryLevel ?? 85;
  const batteryColor = battery > 50 ? "#4ade80" : battery > 20 ? "var(--warn)" : "var(--err)";

  return (
    <div className="px-4 pt-5 pb-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6 animate-slide-up">
        <h1 className="font-display font-bold text-2xl text-white">Profile</h1>
        <img src={triEvLogo} alt="TriEV" className="h-8 w-auto object-contain" />
      </div>

      {/* Avatar + Name Card */}
      <div
        className="rounded-3xl p-5 mb-5 animate-slide-up-delay-1"
        style={{ background: "var(--card)", border: "1px solid var(--border2)" }}
      >
        <div className="flex items-start gap-4">
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0"
            style={{ background: "rgba(255,107,0,0.12)", border: "1.5px solid rgba(255,107,0,0.25)" }}
          >
            <User size={30} style={{ color: "var(--accent)" }} />
          </div>
          <div className="flex-1 min-w-0">
            {editing ? (
              <div className="space-y-2">
                <input
                  className="input-field text-sm"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your name"
                />
                <input
                  className="input-field text-sm"
                  value={evModel}
                  onChange={(e) => setEvModel(e.target.value)}
                  placeholder="EV Model"
                />
                <div className="flex gap-2 mt-2">
                  <button
                    onClick={() => mutation.mutate()}
                    disabled={mutation.isPending}
                    className="flex-1 py-2 rounded-xl text-xs font-bold text-white flex items-center justify-center gap-1.5"
                    style={{ background: "var(--accent)" }}
                  >
                    <Check size={14} /> Save
                  </button>
                  <button
                    onClick={() => { setEditing(false); setName(user.name); setEvModel(user.evModel ?? ""); }}
                    className="flex-1 py-2 rounded-xl text-xs font-bold"
                    style={{ background: "var(--bg3)", color: "var(--text2)", border: "1px solid var(--border2)" }}
                  >
                    <X size={14} className="inline mr-1" /> Cancel
                  </button>
                </div>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <h2 className="font-display font-bold text-xl text-white truncate">{user.name}</h2>
                  <button onClick={() => setEditing(true)} className="p-1.5 rounded-lg" style={{ background: "var(--bg3)" }}>
                    <Edit3 size={15} style={{ color: "var(--text2)" }} />
                  </button>
                </div>
                <p className="text-[var(--text2)] text-sm mt-0.5">{user.evModel}</p>
                <div className="flex items-center gap-1.5 mt-1.5">
                  <Phone size={12} style={{ color: "var(--text3)" }} />
                  <span className="text-[var(--text3)] text-xs">{user.phone}</span>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Battery status */}
      <div
        className="rounded-2xl p-4 mb-5 animate-slide-up-delay-2 flex items-center gap-4"
        style={{ background: "var(--card)", border: "1px solid var(--border)" }}
      >
        <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "var(--bg3)" }}>
          <Battery size={20} style={{ color: batteryColor }} />
        </div>
        <div className="flex-1">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-white font-semibold text-sm">Battery Level</span>
            <span className="font-bold text-sm" style={{ color: batteryColor }}>{battery}%</span>
          </div>
          <div className="h-2 rounded-full overflow-hidden" style={{ background: "var(--bg3)" }}>
            <div className="h-full rounded-full" style={{ width: `${battery}%`, background: batteryColor, boxShadow: `0 0 6px ${batteryColor}80` }} />
          </div>
        </div>
      </div>

      {/* Info rows */}
      <div
        className="rounded-2xl mb-5 overflow-hidden animate-slide-up-delay-3"
        style={{ background: "var(--card)", border: "1px solid var(--border)" }}
      >
        {[
          { icon: User, label: "Member ID", value: `#${user.id.toString().padStart(6, "0")}` },
          { icon: Zap, label: "EV Model", value: user.evModel ?? "—" },
          { icon: Phone, label: "Phone", value: user.phone },
        ].map(({ icon: Icon, label, value }, i) => (
          <div
            key={label}
            className="flex items-center gap-3 px-4 py-3.5"
            style={{ borderBottom: i < 2 ? "1px solid var(--border)" : undefined }}
          >
            <Icon size={17} style={{ color: "var(--text3)" }} />
            <span className="text-[var(--text2)] text-sm w-24">{label}</span>
            <span className="text-white text-sm font-medium flex-1">{value}</span>
          </div>
        ))}
      </div>

      {/* About TriEV */}
      <div
        className="rounded-2xl p-4 mb-5 animate-slide-up-delay-4 flex items-center gap-3"
        style={{ background: "var(--accent-dim)", border: "1px solid rgba(255,107,0,0.2)" }}
      >
        <img src={triEvLogo} alt="TriEV" className="h-8 w-auto object-contain" />
        <div className="flex-1">
          <p className="text-white text-xs font-bold">TriEV Rider App v1.0</p>
          <p className="text-[var(--text2)] text-[11px] mt-0.5">#JoinTheEVTribe</p>
        </div>
      </div>

      {/* Logout */}
      <button
        onClick={logout}
        className="w-full flex items-center justify-between px-4 py-4 rounded-2xl transition-all active:scale-98 animate-slide-up-delay-4"
        style={{ background: "rgba(255,92,92,0.08)", border: "1px solid rgba(255,92,92,0.2)" }}
      >
        <div className="flex items-center gap-3">
          <LogOut size={18} style={{ color: "var(--err)" }} />
          <span className="font-semibold text-sm" style={{ color: "var(--err)" }}>Log Out</span>
        </div>
        <ChevronRight size={16} style={{ color: "var(--err)" }} />
      </button>
    </div>
  );
}
