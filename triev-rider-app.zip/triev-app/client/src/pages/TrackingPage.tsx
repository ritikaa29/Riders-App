import { useEffect, useState } from "react";
import { useLocation, useParams } from "wouter";
import { ArrowLeft, Phone, Star, MapPin, Clock, CheckCircle2, Zap, User, ChevronRight } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAppStore } from "../store/app";
import { apiClient } from "../lib/api";
import { getIssueLabel, getStatusLabel } from "../lib/utils";
import type { Ticket } from "@shared/schema";

const STEPS = [
  { key: "SEARCHING", label: "Searching Technician" },
  { key: "ASSIGNED", label: "Technician Assigned" },
  { key: "EN_ROUTE", label: "En Route" },
  { key: "ARRIVED", label: "Arrived" },
  { key: "IN_PROGRESS", label: "In Progress" },
  { key: "COMPLETED", label: "Completed" },
];

function getStepIndex(status: string) {
  return STEPS.findIndex((s) => s.key === status);
}

export default function TrackingPage() {
  const params = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const setActiveTicket = useAppStore((s) => s.setActiveTicket);
  const qc = useQueryClient();

  const { data: ticket, refetch } = useQuery({
    queryKey: ["ticket", params.id],
    queryFn: () => apiClient.getTicket(Number(params.id)),
    refetchInterval: 3000,
    enabled: !!params.id,
  });

  useEffect(() => {
    if (ticket) setActiveTicket(ticket);
  }, [ticket]);

  const cancelMutation = useMutation({
    mutationFn: () => apiClient.updateTicket(Number(params.id), { status: "CANCELLED" }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["ticket", params.id] });
      qc.invalidateQueries({ queryKey: ["tickets"] });
      navigate("/");
    },
  });

  if (!ticket) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 rounded-full border-2 border-[var(--border2)] border-t-[var(--accent)] animate-spin" />
      </div>
    );
  }

  const isSearching = ticket.status === "SEARCHING";
  const isAssigned = ["ASSIGNED", "EN_ROUTE", "ARRIVED", "IN_PROGRESS"].includes(ticket.status);
  const isCompleted = ticket.status === "COMPLETED";
  const isCancelled = ticket.status === "CANCELLED";
  const stepIndex = getStepIndex(ticket.status);

  return (
    <div className="px-4 pt-5 pb-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6 animate-slide-up">
        <button
          onClick={() => navigate("/")}
          className="w-10 h-10 rounded-xl flex items-center justify-center"
          style={{ background: "var(--bg3)", border: "1px solid var(--border2)" }}
        >
          <ArrowLeft size={20} color="white" />
        </button>
        <div className="flex-1">
          <h1 className="font-display font-bold text-xl text-white">Rescue Status</h1>
          <p className="text-[var(--text2)] text-xs mt-0.5">Ticket #{ticket.id} · {getIssueLabel(ticket.issueType)}</p>
        </div>
      </div>

      {/* Radar / Search Animation */}
      {isSearching && (
        <div className="flex flex-col items-center py-8 mb-6 animate-slide-up-delay-1">
          <div className="relative w-44 h-44 flex items-center justify-center mb-5">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="radar-ring absolute w-full h-full rounded-full"
                style={{
                  border: "2px solid rgba(255,107,0,0.4)",
                  animationDelay: `${i * 0.8}s`,
                }}
              />
            ))}
            <div
              className="w-20 h-20 rounded-full flex items-center justify-center z-10"
              style={{
                background: "linear-gradient(135deg, var(--accent) 0%, #FF9500 100%)",
                boxShadow: "0 0 32px rgba(255,107,0,0.5)",
              }}
            >
              <Zap size={36} color="white" fill="white" />
            </div>
          </div>
          <h2 className="font-display font-bold text-xl text-white mb-1">Searching Nearby…</h2>
          <p className="text-[var(--text2)] text-sm text-center">Finding the closest available technician</p>
          <div className="flex items-center gap-1.5 mt-3">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="w-2 h-2 rounded-full"
                style={{
                  background: "var(--accent)",
                  animation: `ping2 1.5s ease-in-out ${i * 0.3}s infinite`,
                }}
              />
            ))}
          </div>
        </div>
      )}

      {/* Assigned Card */}
      {isAssigned && ticket.techName && (
        <div
          className="rounded-3xl p-5 mb-5 animate-slide-up-delay-1"
          style={{
            background: "linear-gradient(135deg, rgba(255,107,0,0.1) 0%, rgba(255,149,0,0.05) 100%)",
            border: "1.5px solid rgba(255,107,0,0.3)",
          }}
        >
          <div className="flex items-center gap-3 mb-4">
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0"
              style={{ background: "rgba(255,107,0,0.15)" }}
            >
              <User size={28} style={{ color: "var(--accent)" }} />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <h3 className="font-display font-bold text-white text-lg">{ticket.techName}</h3>
                {ticket.techRating && (
                  <div className="flex items-center gap-1 px-2 py-0.5 rounded-full" style={{ background: "rgba(255,179,64,0.1)", border: "1px solid rgba(255,179,64,0.25)" }}>
                    <Star size={11} fill="#FFB340" color="#FFB340" />
                    <span className="text-xs font-bold text-[var(--warn)]">{ticket.techRating}</span>
                  </div>
                )}
              </div>
              <p className="text-[var(--text2)] text-xs mt-0.5">Verified TriEV Technician</p>
            </div>
          </div>

          {ticket.eta && (
            <div
              className="flex items-center gap-2 p-3 rounded-xl mb-3"
              style={{ background: "rgba(255,107,0,0.08)", border: "1px solid rgba(255,107,0,0.15)" }}
            >
              <Clock size={16} style={{ color: "var(--accent)" }} />
              <span className="text-sm font-bold text-white">ETA:</span>
              <span className="text-[var(--accent)] font-extrabold font-display text-lg">{ticket.eta}</span>
            </div>
          )}

          {ticket.techPhone && (
            <a
              href={`tel:${ticket.techPhone}`}
              className="btn-secondary flex items-center justify-center gap-2 no-underline"
            >
              <Phone size={17} style={{ color: "var(--accent)" }} />
              <span style={{ color: "var(--accent)" }}>Call Technician</span>
            </a>
          )}
        </div>
      )}

      {/* Completed Card */}
      {isCompleted && (
        <div
          className="rounded-3xl p-5 mb-5 flex flex-col items-center text-center animate-slide-up-delay-1"
          style={{ background: "rgba(34,197,94,0.08)", border: "1.5px solid rgba(34,197,94,0.25)" }}
        >
          <CheckCircle2 size={52} color="#4ade80" className="mb-3" />
          <h3 className="font-display font-bold text-xl text-white mb-1">Rescue Complete!</h3>
          <p className="text-[var(--text2)] text-sm">Your EV has been serviced. Safe riding!</p>
        </div>
      )}

      {/* Ticket Info */}
      <div className="card p-4 mb-5 animate-slide-up-delay-2">
        <h4 className="text-[var(--text2)] text-xs font-bold uppercase tracking-wider mb-3">Ticket Details</h4>
        <div className="space-y-3">
          <InfoRow label="Issue" value={getIssueLabel(ticket.issueType)} />
          <InfoRow label="Status" value={getStatusLabel(ticket.status)} />
          <InfoRow label="Priority" value={ticket.priority} />
          <InfoRow label="Location" value={ticket.locationText} icon={<MapPin size={14} />} />
          {ticket.issueDescription && <InfoRow label="Description" value={ticket.issueDescription} />}
        </div>
      </div>

      {/* Progress Steps */}
      {!isCancelled && (
        <div className="card p-4 mb-5 animate-slide-up-delay-3">
          <h4 className="text-[var(--text2)] text-xs font-bold uppercase tracking-wider mb-4">Progress</h4>
          <div className="relative">
            {/* Vertical line */}
            <div
              className="absolute left-4 top-4 bottom-4 w-0.5"
              style={{ background: "var(--border2)" }}
            />
            <div
              className="absolute left-4 top-4 w-0.5 transition-all duration-700"
              style={{
                background: "var(--accent)",
                height: `${(stepIndex / (STEPS.length - 1)) * 100}%`,
              }}
            />
            <div className="space-y-4">
              {STEPS.map((step, i) => {
                const done = i < stepIndex;
                const current = i === stepIndex;
                return (
                  <div key={step.key} className="flex items-center gap-4">
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 z-10 transition-all duration-300"
                      style={{
                        background: done || current ? "var(--accent)" : "var(--bg3)",
                        border: `2px solid ${done || current ? "var(--accent)" : "var(--border2)"}`,
                        boxShadow: current ? "0 0 12px var(--accent-glow)" : "none",
                      }}
                    >
                      {done ? (
                        <CheckCircle2 size={14} color="white" fill="white" />
                      ) : (
                        <div className={`w-2.5 h-2.5 rounded-full ${current ? "bg-white animate-pulse" : "bg-[var(--text3)]"}`} />
                      )}
                    </div>
                    <span
                      className="text-sm font-semibold transition-all"
                      style={{ color: current ? "white" : done ? "var(--text2)" : "var(--text3)" }}
                    >
                      {step.label}
                    </span>
                    {current && <span className="text-[10px] px-2 py-0.5 rounded-full font-bold badge-assigned ml-auto">Now</span>}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Cancel Button */}
      {isSearching && (
        <button
          className="w-full py-4 rounded-2xl font-bold text-sm transition-all active:scale-95"
          style={{ background: "rgba(255,92,92,0.1)", border: "1px solid rgba(255,92,92,0.25)", color: "var(--err)" }}
          onClick={() => cancelMutation.mutate()}
          disabled={cancelMutation.isPending}
        >
          Cancel Request
        </button>
      )}
    </div>
  );
}

function InfoRow({ label, value, icon }: { label: string; value: string; icon?: React.ReactNode }) {
  return (
    <div className="flex items-start gap-2">
      <span className="text-[var(--text3)] text-xs w-20 flex-shrink-0 mt-0.5 font-medium">{label}</span>
      <div className="flex items-start gap-1.5 flex-1">
        {icon && <span style={{ color: "var(--text3)" }} className="mt-0.5">{icon}</span>}
        <span className="text-white text-sm font-medium">{value}</span>
      </div>
    </div>
  );
}
