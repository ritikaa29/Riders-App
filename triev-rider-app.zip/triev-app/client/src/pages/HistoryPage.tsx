import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Clock, ChevronRight, Zap } from "lucide-react";
import { useAppStore } from "../store/app";
import { apiClient } from "../lib/api";
import { getIssueLabel, getStatusLabel, getStatusClass, formatDate, formatTime } from "../lib/utils";
import type { Ticket } from "@shared/schema";

export default function HistoryPage() {
  const [, navigate] = useLocation();
  const user = useAppStore((s) => s.user);
  const setActiveTicket = useAppStore((s) => s.setActiveTicket);

  const { data: tickets = [], isLoading } = useQuery({
    queryKey: ["tickets", user?.id],
    queryFn: () => apiClient.getTickets(user!.id),
    enabled: !!user,
  });

  const sorted = [...tickets].sort(
    (a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
  );

  const handleOpen = (ticket: Ticket) => {
    if (!["COMPLETED", "CANCELLED"].includes(ticket.status)) {
      setActiveTicket(ticket);
      navigate(`/tracking/${ticket.id}`);
    }
  };

  return (
    <div className="px-4 pt-5 pb-4">
      {/* Header */}
      <div className="mb-6 animate-slide-up">
        <h1 className="font-display font-bold text-2xl text-white">Rescue History</h1>
        <p className="text-[var(--text2)] text-sm mt-1">All your past & active rescues</p>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="w-8 h-8 rounded-full border-2 border-[var(--border2)] border-t-[var(--accent)] animate-spin" />
        </div>
      ) : sorted.length === 0 ? (
        <EmptyState />
      ) : (
        <div className="space-y-3 animate-slide-up-delay-1">
          {sorted.map((ticket) => (
            <TicketCard key={ticket.id} ticket={ticket} onClick={() => handleOpen(ticket)} />
          ))}
        </div>
      )}
    </div>
  );
}

function TicketCard({ ticket, onClick }: { ticket: Ticket; onClick: () => void }) {
  const isActive = !["COMPLETED", "CANCELLED"].includes(ticket.status);

  return (
    <button
      onClick={onClick}
      className="w-full text-left flex items-start gap-3 p-4 rounded-2xl transition-all active:scale-98"
      style={{ background: "var(--card)", border: `1px solid ${isActive ? "rgba(255,107,0,0.25)" : "var(--border)"}` }}
    >
      <div
        className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5"
        style={{ background: isActive ? "rgba(255,107,0,0.12)" : "var(--bg3)" }}
      >
        <Zap size={20} style={{ color: isActive ? "var(--accent)" : "var(--text3)" }} fill={isActive ? "currentColor" : "none"} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between mb-1">
          <span className="font-bold text-sm text-white">{getIssueLabel(ticket.issueType)}</span>
          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${getStatusClass(ticket.status)}`}>
            {getStatusLabel(ticket.status)}
          </span>
        </div>
        <p className="text-[var(--text2)] text-xs truncate mb-1">{ticket.locationText}</p>
        <div className="flex items-center gap-2">
          <Clock size={11} style={{ color: "var(--text3)" }} />
          <span className="text-[var(--text3)] text-[11px]">
            {formatDate(ticket.createdAt)} · {formatTime(ticket.createdAt)}
          </span>
        </div>
        {ticket.techName && (
          <p className="text-[var(--accent)] text-xs font-semibold mt-1">Tech: {ticket.techName}</p>
        )}
      </div>
      {isActive && <ChevronRight size={16} style={{ color: "var(--text3)" }} className="mt-3" />}
    </button>
  );
}

function EmptyState() {
  const [, navigate] = useLocation();
  return (
    <div className="flex flex-col items-center py-20 text-center">
      <div
        className="w-20 h-20 rounded-2xl flex items-center justify-center mb-5"
        style={{ background: "var(--bg3)", border: "1px solid var(--border2)" }}
      >
        <Clock size={36} style={{ color: "var(--text3)" }} />
      </div>
      <h3 className="font-display font-bold text-white text-lg mb-2">No Rescues Yet</h3>
      <p className="text-[var(--text2)] text-sm mb-6 max-w-xs">
        You haven't raised any SOS tickets yet. We're here when you need us.
      </p>
      <button className="btn-primary w-auto px-8" onClick={() => navigate("/raise-ticket")}>
        Raise First Ticket
      </button>
    </div>
  );
}
