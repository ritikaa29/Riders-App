import { useState } from "react";
import { useLocation } from "wouter";
import { ArrowLeft, MapPin, Loader2, ZapOff, Circle, AlertTriangle, Lock, MoreHorizontal, Navigation } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { useAppStore } from "../store/app";
import { apiClient } from "../lib/api";
import { cn } from "../lib/utils";

const ISSUES = [
  { id: "BATTERY", label: "Battery Dead", icon: ZapOff, color: "#FF6B00" },
  { id: "TIRE", label: "Flat Tyre", icon: Circle, color: "#FFB340" },
  { id: "SYSTEM", label: "System Error", icon: AlertTriangle, color: "#FF5C5C" },
  { id: "LOCKOUT", label: "Lock Out", icon: Lock, color: "#60a5fa" },
  { id: "OTHER", label: "Other", icon: MoreHorizontal, color: "#a78bfa" },
];

export default function RaiseTicketPage() {
  const [, navigate] = useLocation();
  const user = useAppStore((s) => s.user);
  const setActiveTicket = useAppStore((s) => s.setActiveTicket);

  const [issueType, setIssueType] = useState("");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");
  const [gpsLoading, setGpsLoading] = useState(false);
  const [priority, setPriority] = useState<"NORMAL" | "HIGH" | "URGENT">("NORMAL");

  const handleDetectLocation = () => {
    setGpsLoading(true);
    navigator.geolocation?.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        try {
          const res = await fetch(
            `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`
          );
          const data = await res.json();
          setLocation(data.display_name?.split(",").slice(0, 4).join(", ") ?? `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`);
        } catch {
          setLocation(`${latitude.toFixed(4)}, ${longitude.toFixed(4)}`);
        } finally {
          setGpsLoading(false);
        }
      },
      () => {
        setLocation("Location detection failed");
        setGpsLoading(false);
      }
    );
  };

  const mutation = useMutation({
    mutationFn: () =>
      apiClient.createTicket({
        userId: user!.id,
        issueType,
        issueDescription: description || undefined,
        locationText: location,
        priority,
        status: "SEARCHING",
      }),
    onSuccess: (ticket) => {
      setActiveTicket(ticket);
      navigate(`/tracking/${ticket.id}`);
    },
  });

  const canSubmit = issueType && location.trim().length > 3;

  return (
    <div className="px-4 pt-5 pb-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-7 animate-slide-up">
        <button
          onClick={() => navigate("/")}
          className="w-10 h-10 rounded-xl flex items-center justify-center transition-all active:scale-95"
          style={{ background: "var(--bg3)", border: "1px solid var(--border2)" }}
        >
          <ArrowLeft size={20} color="white" />
        </button>
        <div>
          <h1 className="font-display font-bold text-xl text-white">Raise SOS Ticket</h1>
          <p className="text-[var(--text2)] text-xs mt-0.5">We'll find a technician near you</p>
        </div>
      </div>

      {/* Issue Type */}
      <div className="mb-6 animate-slide-up-delay-1">
        <label className="block text-[var(--text2)] text-xs font-bold uppercase tracking-wider mb-3">
          What's the issue?
        </label>
        <div className="grid grid-cols-3 gap-2.5">
          {ISSUES.map(({ id, label, icon: Icon, color }) => (
            <button
              key={id}
              onClick={() => setIssueType(id)}
              className={cn("issue-chip", issueType === id && "selected")}
            >
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center"
                style={{
                  background: issueType === id ? `${color}25` : "var(--bg2)",
                  border: `1px solid ${issueType === id ? color : "var(--border)"}`,
                }}
              >
                <Icon size={18} color={issueType === id ? color : "var(--text3)"} strokeWidth={2} />
              </div>
              <span
                className="text-xs font-semibold text-center leading-tight"
                style={{ color: issueType === id ? "white" : "var(--text2)" }}
              >
                {label}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Priority */}
      <div className="mb-6 animate-slide-up-delay-2">
        <label className="block text-[var(--text2)] text-xs font-bold uppercase tracking-wider mb-3">
          Priority
        </label>
        <div className="flex gap-2">
          {(["NORMAL", "HIGH", "URGENT"] as const).map((p) => {
            const colors = { NORMAL: "#60a5fa", HIGH: "var(--warn)", URGENT: "var(--err)" };
            const active = priority === p;
            return (
              <button
                key={p}
                onClick={() => setPriority(p)}
                className="flex-1 py-2.5 rounded-xl text-xs font-bold transition-all active:scale-95"
                style={{
                  background: active ? `${colors[p]}18` : "var(--bg3)",
                  border: `1.5px solid ${active ? colors[p] : "var(--border2)"}`,
                  color: active ? colors[p] : "var(--text3)",
                }}
              >
                {p}
              </button>
            );
          })}
        </div>
      </div>

      {/* Location */}
      <div className="mb-6 animate-slide-up-delay-3">
        <label className="block text-[var(--text2)] text-xs font-bold uppercase tracking-wider mb-3">
          Your Location
        </label>
        <div className="relative">
          <MapPin
            size={16}
            className="absolute left-3.5 top-1/2 -translate-y-1/2"
            style={{ color: location ? "var(--accent)" : "var(--text3)" }}
          />
          <input
            type="text"
            className="input-field pl-9 pr-24"
            placeholder="Enter your location…"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          />
          <button
            onClick={handleDetectLocation}
            disabled={gpsLoading}
            className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all active:scale-95"
            style={{ background: "var(--bg2)", color: "var(--accent)" }}
          >
            {gpsLoading ? <Loader2 size={13} className="animate-spin" /> : <Navigation size={13} />}
            {gpsLoading ? "..." : "Auto"}
          </button>
        </div>
      </div>

      {/* Description */}
      {(issueType === "OTHER" || description) && (
        <div className="mb-6 animate-slide-up">
          <label className="block text-[var(--text2)] text-xs font-bold uppercase tracking-wider mb-3">
            Describe the Issue
          </label>
          <textarea
            className="input-field resize-none"
            rows={3}
            placeholder="Describe what happened…"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </div>
      )}

      {/* Error */}
      {mutation.isError && (
        <div className="mb-4 p-3 rounded-xl text-[var(--err)] text-sm font-medium" style={{ background: "rgba(255,92,92,0.1)", border: "1px solid rgba(255,92,92,0.2)" }}>
          {(mutation.error as Error)?.message ?? "Something went wrong"}
        </div>
      )}

      {/* Submit */}
      <button
        className="btn-primary animate-slide-up-delay-4 disabled:opacity-50 disabled:cursor-not-allowed"
        disabled={!canSubmit || mutation.isPending}
        onClick={() => mutation.mutate()}
      >
        {mutation.isPending ? (
          <>
            <Loader2 size={18} className="animate-spin" /> Dispatching…
          </>
        ) : (
          <>
            <AlertTriangle size={18} fill="white" /> Send SOS
          </>
        )}
      </button>
    </div>
  );
}
