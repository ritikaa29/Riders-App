import type { User, Ticket, InsertTicket } from "@shared/schema";

const BASE = "";

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: "Request failed" }));
    throw new Error(err.message || "Request failed");
  }
  return res.json();
}

export const apiClient = {
  login: (phone: string, name?: string) =>
    request<User>("POST", "/api/users/login", { phone, name }),

  getUser: (id: number) =>
    request<User>("GET", `/api/users/${id}`),

  updateUser: (id: number, data: Partial<User>) =>
    request<User>("PUT", `/api/users/${id}`, data),

  getTickets: (userId: number) =>
    request<Ticket[]>("GET", `/api/tickets?userId=${userId}`),

  getTicket: (id: number) =>
    request<Ticket>("GET", `/api/tickets/${id}`),

  createTicket: (data: InsertTicket) =>
    request<Ticket>("POST", "/api/tickets", data),

  updateTicket: (id: number, data: Partial<InsertTicket>) =>
    request<Ticket>("PUT", `/api/tickets/${id}`, data),
};
