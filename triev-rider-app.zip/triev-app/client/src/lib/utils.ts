import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: string | Date | null | undefined): string {
  if (!date) return "—";
  return new Date(date).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export function formatTime(date: string | Date | null | undefined): string {
  if (!date) return "—";
  return new Date(date).toLocaleTimeString("en-IN", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function formatDateTime(date: string | Date | null | undefined): string {
  if (!date) return "—";
  return `${formatDate(date)}, ${formatTime(date)}`;
}

export function getIssueLabel(type: string): string {
  const map: Record<string, string> = {
    BATTERY: "Battery Dead",
    TIRE: "Flat Tyre",
    SYSTEM: "System Error",
    LOCKOUT: "Lock Out",
    OTHER: "Other Issue",
  };
  return map[type] ?? type;
}

export function getStatusLabel(status: string): string {
  const map: Record<string, string> = {
    SEARCHING: "Searching",
    ASSIGNED: "Assigned",
    EN_ROUTE: "On the Way",
    ARRIVED: "Arrived",
    IN_PROGRESS: "In Progress",
    COMPLETED: "Completed",
    CANCELLED: "Cancelled",
  };
  return map[status] ?? status;
}

export function getStatusClass(status: string): string {
  if (status === "SEARCHING") return "badge-searching";
  if (status === "ASSIGNED" || status === "EN_ROUTE" || status === "ARRIVED" || status === "IN_PROGRESS") return "badge-assigned";
  if (status === "COMPLETED") return "badge-completed";
  return "badge-cancelled";
}
