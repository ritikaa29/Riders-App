import { useEffect } from "react";
import { Route, Switch } from "wouter";
import { useAppStore } from "./store/app";
import LoginPage from "./pages/LoginPage";
import HomePage from "./pages/HomePage";
import RaiseTicketPage from "./pages/RaiseTicketPage";
import TrackingPage from "./pages/TrackingPage";
import HistoryPage from "./pages/HistoryPage";
import ProfilePage from "./pages/ProfilePage";
import BottomNav from "./components/BottomNav";

function AuthenticatedApp() {
  return (
    <div className="flex flex-col h-full max-w-md mx-auto relative">
      <div className="flex-1 overflow-y-auto scrollbar-hide pb-20">
        <Switch>
          <Route path="/" component={HomePage} />
          <Route path="/raise-ticket" component={RaiseTicketPage} />
          <Route path="/tracking/:id" component={TrackingPage} />
          <Route path="/history" component={HistoryPage} />
          <Route path="/profile" component={ProfilePage} />
          <Route component={HomePage} />
        </Switch>
      </div>
      <BottomNav />
    </div>
  );
}

export default function App() {
  const user = useAppStore((s) => s.user);

  return (
    <div className="h-full bg-[var(--bg)]">
      {!user ? (
        <LoginPage />
      ) : (
        <AuthenticatedApp />
      )}
    </div>
  );
}
