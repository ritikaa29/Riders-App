import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { User, Ticket } from "@shared/schema";

interface AppState {
  user: User | null;
  activeTicket: Ticket | null;
  setUser: (user: User | null) => void;
  setActiveTicket: (ticket: Ticket | null) => void;
  logout: () => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      user: null,
      activeTicket: null,
      setUser: (user) => set({ user }),
      setActiveTicket: (ticket) => set({ activeTicket: ticket }),
      logout: () => set({ user: null, activeTicket: null }),
    }),
    {
      name: "triev-storage",
      partialize: (state) => ({ user: state.user }),
    }
  )
);
