import { useLocation } from "wouter";
import { Home, Clock, User } from "lucide-react";
import { cn } from "../lib/utils";

const navItems = [
  { path: "/", label: "Home", icon: Home },
  { path: "/history", label: "History", icon: Clock },
  { path: "/profile", label: "Profile", icon: User },
];

export default function BottomNav() {
  const [location, navigate] = useLocation();

  return (
    <div
      className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md px-4 pb-4 z-50"
      style={{ background: "linear-gradient(to top, var(--bg) 60%, transparent)" }}
    >
      <div
        className="flex items-center justify-around px-2 py-1 rounded-2xl"
        style={{
          background: "var(--card)",
          border: "1px solid var(--border2)",
          backdropFilter: "blur(12px)",
        }}
      >
        {navItems.map(({ path, label, icon: Icon }) => {
          const active = location === path;
          return (
            <button
              key={path}
              onClick={() => navigate(path)}
              className={cn(
                "bottom-nav-item",
                active ? "text-[var(--accent)]" : "text-[var(--text3)]"
              )}
            >
              <Icon size={22} strokeWidth={active ? 2.5 : 1.8} />
              <span
                className={cn(
                  "text-xs font-semibold transition-all",
                  active ? "text-[var(--accent)]" : "text-[var(--text3)]"
                )}
              >
                {label}
              </span>
              {active && (
                <span
                  className="absolute bottom-1 w-1 h-1 rounded-full bg-[var(--accent)]"
                  style={{ boxShadow: "0 0 6px var(--accent)" }}
                />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
