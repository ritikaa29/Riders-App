import express from "express";
import { createServer } from "http";
import path from "path";
import { registerRoutes } from "./routes";

const app = express();
const PORT = process.env.PORT || 3001;

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Serve static files in production
if (process.env.NODE_ENV === "production") {
  app.use(express.static(path.join(__dirname, "../client")));
}

const httpServer = createServer(app);

registerRoutes(httpServer, app).then((server) => {
  // Serve React app for all non-API routes in production
  if (process.env.NODE_ENV === "production") {
    app.get("*", (_req, res) => {
      res.sendFile(path.join(__dirname, "../client/index.html"));
    });
  }

  server.listen(PORT, () => {
    console.log(`🔋 TriEV Server running on port ${PORT}`);
  });
});
