import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import { eq, and } from "drizzle-orm";
import * as schema from "@shared/schema";
import type { InsertUser, InsertTicket, User, Ticket } from "@shared/schema";

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

const db = drizzle(pool, { schema });

export const storage = {
  async getUserByPhone(phone: string): Promise<User | null> {
    const result = await db.select().from(schema.users).where(eq(schema.users.phone, phone)).limit(1);
    return result[0] ?? null;
  },

  async getUserById(id: number): Promise<User | null> {
    const result = await db.select().from(schema.users).where(eq(schema.users.id, id)).limit(1);
    return result[0] ?? null;
  },

  async createUser(data: InsertUser): Promise<User> {
    const result = await db.insert(schema.users).values(data).returning();
    return result[0];
  },

  async updateUser(id: number, data: Partial<InsertUser>): Promise<User> {
    const result = await db.update(schema.users).set(data).where(eq(schema.users.id, id)).returning();
    return result[0];
  },

  async getTickets(userId?: number, status?: string): Promise<Ticket[]> {
    if (userId && status) {
      return db.select().from(schema.tickets)
        .where(and(eq(schema.tickets.userId, userId), eq(schema.tickets.status, status)));
    }
    if (userId) {
      return db.select().from(schema.tickets).where(eq(schema.tickets.userId, userId));
    }
    if (status) {
      return db.select().from(schema.tickets).where(eq(schema.tickets.status, status));
    }
    return db.select().from(schema.tickets);
  },

  async getTicketById(id: number): Promise<Ticket | null> {
    const result = await db.select().from(schema.tickets).where(eq(schema.tickets.id, id)).limit(1);
    return result[0] ?? null;
  },

  async createTicket(data: InsertTicket): Promise<Ticket> {
    const result = await db.insert(schema.tickets).values(data).returning();
    return result[0];
  },

  async updateTicket(id: number, data: Partial<InsertTicket>): Promise<Ticket> {
    const result = await db.update(schema.tickets).set(data).where(eq(schema.tickets.id, id)).returning();
    return result[0];
  },
};
