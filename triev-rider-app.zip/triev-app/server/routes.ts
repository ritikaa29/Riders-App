import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {

  // Auth
  app.post(api.users.login.path, async (req, res) => {
    try {
      const input = api.users.login.input.parse(req.body);
      let user = await storage.getUserByPhone(input.phone);
      if (!user) {
        user = await storage.createUser({
          phone: input.phone,
          name: input.name || "Rider",
          evModel: "TriEV 300",
          batteryLevel: 85,
        });
      }
      res.status(200).json(user);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      console.error(err);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get user by id
  app.get(api.users.get.path, async (req, res) => {
    try {
      const user = await storage.getUserById(Number(req.params.id));
      if (!user) return res.status(404).json({ message: "User not found" });
      res.json(user);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Update user
  app.put(api.users.update.path, async (req, res) => {
    try {
      const input = api.users.update.input.parse(req.body);
      const user = await storage.updateUser(Number(req.params.id), input);
      res.json(user);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // List tickets
  app.get(api.tickets.list.path, async (req, res) => {
    try {
      const userId = req.query.userId ? Number(req.query.userId) : undefined;
      const status = req.query.status ? String(req.query.status) : undefined;
      const tickets = await storage.getTickets(userId, status);
      res.json(tickets);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get ticket
  app.get(api.tickets.get.path, async (req, res) => {
    try {
      const ticket = await storage.getTicketById(Number(req.params.id));
      if (!ticket) return res.status(404).json({ message: "Ticket not found" });
      res.json(ticket);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Create ticket
  app.post(api.tickets.create.path, async (req, res) => {
    try {
      const input = api.tickets.create.input.parse(req.body);
      const ticket = await storage.createTicket(input);

      // Simulate tech assignment after 8 seconds
      setTimeout(async () => {
        try {
          await storage.updateTicket(ticket.id, {
            status: "ASSIGNED",
            techName: "Ravi Kumar",
            techPhone: "+91 98765 43210",
            techRating: "4.9",
            eta: "12 mins",
          });
        } catch (e) {
          console.error("Auto-assign error:", e);
        }
      }, 8000);

      res.status(201).json(ticket);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Update ticket
  app.put(api.tickets.update.path, async (req, res) => {
    try {
      const input = api.tickets.update.input.parse(req.body);
      const ticket = await storage.updateTicket(Number(req.params.id), input);
      res.json(ticket);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  return httpServer;
}
